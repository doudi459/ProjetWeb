<?php echo '{
    "sec2art1": [
        "au debut de ma vie je reves maintenan nn&nbsp;",
        ".\/Modelutilisateur\/bibliotheque\/77894b4f185c03363af7cacfefc38fead1686e47.jpg"
    ]
}'?>